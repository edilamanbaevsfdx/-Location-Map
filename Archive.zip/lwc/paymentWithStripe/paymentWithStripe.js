import { LightningElement, api } from "lwc";
import getCustomerIdMethod from "@salesforce/apex/paymentWithStripeController.getCustomerId";
import getCardIdMethod from "@salesforce/apex/paymentWithStripeController.getCardId";
import email from "@salesforce/apex/paymentWithStripeController.sendSingleEmail";
import getDueAmountCalculator from "@salesforce/apex/paymentWithStripeController.calcDueAmount";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
export default class PaymentWithStripe extends LightningElement {
  showStartTemplate = true;
  showPersonalInfoTemplate = false;
  showPaymentTemplate = false;
  showEndTemplate = false;
  showEmailBtn = false;
  name;
  email;
  phone;
  address;
  city;
  state;
  zip;
  /////////////////////////////////////////////////////////////////////
  startHandler() {
    this.showStartTemplate = false;
    this.showPersonalInfoTemplate = true;
  }
  /////////////////////////////////////////////////////////////////////
  personal_Info_Change_Handler(event) {
    if (event.target.name === "name") {
      this.name = event.target.value;
    }
    if (event.target.name === "email") {
      this.email = event.target.value;
    }
    if (event.target.name === "phone") {
      this.phone = event.target.value;
    }
    if (event.target.name === "address") {
      this.address = event.target.value;
    }
    if (event.target.name === "city") {
      this.city = event.target.value;
    }
    if (event.target.name === "state") {
      this.state = event.target.value;
    }
    if (event.target.name === "zip") {
      this.zip = event.target.value;
    }
  }
  /////////////////////////////////////////////////////////////////////
  nextBtnHandler() {
    getCustomerIdMethod({
      name: this.name,
      email: this.email,
      phone: this.phone
    })
      .then((customerIdData) => {
        //console.log('This is Customer Object in json format'+customerIdData);
        let parsedCustomerId = JSON.parse(customerIdData);
        this.customerId = parsedCustomerId.id;
        console.log("This is Customer ID: " + this.customerId);
        //console.log("This is Customer Object(Parsed): " + parsedCustomerId);
        this.showPersonalInfoTemplate = false;
        this.showPaymentTemplate = true;
      })
      .catch((error) => {
        console.log("Error has occured while fetching customer Id: " + error);
      });
  }
  /////////////////////////////////////////////////////////////////////
  cardNumber;
  expMonth;
  expYear;
  amount;
  cvc;
  selectedCurrency = "USD";
  billing_Info_Change_Handler(event) {
    if (event.target.name === "cardNumber") {
      this.cardNumber = event.target.value;
    } else if (event.target.name === "expiryDate") {
      let fullDate = String(event.target.value);
      this.expYear = fullDate.substring(0, 4);
      this.expMonth = fullDate.substring(5, 7);
      console.log(this.expYear, this.expMonth);
    } else if (event.target.name === "amount") {
      this.amount = event.target.value;
    } else if (event.target.name === "cvc") {
      this.cvc = event.target.value;
    }
  }
  /////////////////////////////////////////////////////////////////////
  transactionNumber;
  receiptLink;
  customerId;
  @api recordId;
  payHandler() {
    this.showEndTemplate = true;
    this.showPaymentTemplate = false;

    getCardIdMethod({
      cardNumber: this.cardNumber,
      expMonth: this.expMonth,
      expYear: this.expYear,
      amount: this.amount,
      customerId: this.customerId,
      cvc: this.cvc,
      selectedCurrency: this.selectedCurrency
    })
      .then((cardIdData) => {
        let parsedCardId = JSON.parse(cardIdData);
        console.log("This is Payment Object(Parsed): " + parsedCardId);
        this.transactionNumber = parsedCardId.balance_transaction;
        this.receiptLink = parsedCardId.receipt_url;
        /// . Displaying toast message when transaction is complete depending on result of transaction
        if (this.transactionNumber != null) {
          this.showEmailBtn = true;
          const successEvt = new ShowToastEvent({
            title: "Rent Payment",
            message: "Your transaction has been successfully completed!",
            variant: "success"
          });
          this.dispatchEvent(successEvt);
          ////////////////////////////////////////////////////////////////////////
          /// . Calculate and update Due Amount
          getDueAmountCalculator({
            recordIdParam: this.recordId,
            paidAmount: this.amount
          })
            .then((data) => {
              console.log(
                "This is data from Due Amount Calculator: " + JSON.parse(data)
              );
              console.log(this.recordId);
              console.log(this.amount);
            })
            .catch((error) => {
              console.log(
                "Error has occured when calculating a due amount: " + error
              );
              console.log(this.recordId);
              console.log(this.amount);
            });
        } else {
          const failEvt = new ShowToastEvent({
            title: "Rent Payment",
            message: "Your transaction has encountered an error!",
            variant: "error"
          });
          this.dispatchEvent(failEvt);
        }
      })
      .catch((error) => {
        console.log("Error has occured while fetching card Id: " + error);
      });
  }
  /////////////////////////////////////////////////////////////////////
  restartHandler() {
    this.showEndTemplate = false;
    this.showStartTemplate = true;
  }
  /////////////////////////////////////////////////////////////////////
  emailHandler() {
    if (this.transactionNumber != null) {
      email({
        toAddress: this.email,
        subject: "Rent Payment Reciept",
        body: `Dear ${this.name},

        Your transaction has been successfully completed! Your transaction number is ${this.transactionNumber}, and the amount you paid is ${this.amount}.
        
        You can view your transaction details at the following link: ${this.receiptLink}.
        
        Thank you for your business.
        
        Sincerely,
        The Management Team`
      });
      const emailSent = new ShowToastEvent({
        title: "Email Message Sent",
        message: "We have sent your reciept to you!",
        variant: "success"
      });
      this.dispatchEvent(emailSent);
    }
  }
}
